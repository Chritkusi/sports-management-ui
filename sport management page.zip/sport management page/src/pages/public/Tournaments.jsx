export default function Tournaments() {
  return (
    <>
      <h2>All Tournaments</h2>
      <ul>
        <li>Inter-Hall Athletics</li>
        <li>Football League</li>
      </ul>
    </>
  );
}