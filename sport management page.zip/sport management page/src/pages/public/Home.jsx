export default function Home() {
  return (
    <>
      <h1>School Sports Management System</h1>
      <p>Welcome to the official sports portal.</p>
    </>
  );
}