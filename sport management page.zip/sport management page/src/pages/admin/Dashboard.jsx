export default function Dashboard() {
  return <h2>Admin Dashboard</h2>;
}